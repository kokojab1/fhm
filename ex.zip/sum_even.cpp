#include <iostream>
using namespace std;

int main() {
    int a, b;
    if(!(cin >> a >> b)) return 0;
    if (a > b) {
        int t = a;
        a = b;
        b = t;
    }
    int s = 0;
    for (int i = a; i <= b; i++) {
        if (i % 2 == 0) s += i;
    }
    cout << s;
    return 0;
}
