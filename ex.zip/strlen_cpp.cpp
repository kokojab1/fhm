#include <iostream>
#include <cstring>
using namespace std;

int main() {
    const char *s = "Hello world";
    cout << strlen(s);
    return 0;
}
