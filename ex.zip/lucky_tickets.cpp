#include <iostream>
using namespace std;

int main() {
    int c = 0;
    for (int n = 0; n <= 999999; n++) {
        int x = n, a = 0, b = 0;
        for (int i = 0; i < 3; i++) {
            a += x % 10;
            x /= 10;
        }
        for (int i = 0; i < 3; i++) {
            b += x % 10;
            x /= 10;
        }
        if (a == b) c++;
    }
    cout << c;
    return 0;
}
