#include <iostream>
#include <string>
using namespace std;

int main() {
    int n;
    if(!(cin >> n)) return 0;
    string s = to_string(n);
    cout << s;
    return 0;
}
