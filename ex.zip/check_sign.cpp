#include <iostream>
using namespace std;

int main() {
    double x;
    if(!(cin >> x)) return 0;
    if (x > 0) cout << "positive";
    else if (x < 0) cout << "negative";
    else cout << "zero";
    return 0;
}
